var mainContent = Vue.component('main-content', ({
    props: ['template'],
    template: `       
     <div class="content">
    <p class="select">Выбери понравившийся шаблон</p>
    <div class="examples">
        <div style="background-image:url(img/img_1.jpg)" :class="template==1 ? 'example active' : 'example'" @click="$emit('template-number', Number(1))"></div>
        <div style="background-image:url(img/img_2.jpg)" :class="template==2 ? 'example active' : 'example'" @click="$emit('template-number', Number(2))"></div>
        <div style="background-image:url(img/img_3.jpg)" :class="template==3 ? 'example active' : 'example'" @click="$emit('template-number', Number(3))"></div>
        <div style="background-image:url(img/img_4.jpg)" :class="template==4 ? 'example active' : 'example'" @click="$emit('template-number', Number(4))"></div>
        <div style="background-image:url(img/img_5.jpg)" :class="template==5 ? 'example active' : 'example'" @click="$emit('template-number', Number(5))"></div>
    </div>
    <div class='select-button'>
        <button type='button' class='select-example-button' @click="$emit('page-number', 'person')" :disabled ='!template'>Выбрать этот шаблон</button>
    </div>
</div>`
}))

