var myHeader = Vue.component('my-header', {
    template: `
        <div class='information'>
            <img src="img/male_face.png" class='about-males' alt='male-face'>
            <p class="make-a-gif">Создай персональную GIF-открытку <br><span class="congrats"> и поздравь коллегу с 23 февраля</span></p>
    </div>
        `
})

