var applyPhoto = Vue.component('apply-photo', ({
    props: ['template', 'img'],
    template: `
    <div class='container'>
    <div class="container-page-3">
    <div class="modal">
        <div class='apply-face'>
        <img :src='img'></div>
        <div class="modal-footer">
            <p class='place-face'>Помести овал лица в выделенную область</p>
            <button type='button' class="select-example-button apply-face-btn"@click="$emit('page-number', 'gif-ready')" :disabled ='!template' >Применить</button>
        </div>
        </div>
    </div>
</div>
    </div>`

}))

